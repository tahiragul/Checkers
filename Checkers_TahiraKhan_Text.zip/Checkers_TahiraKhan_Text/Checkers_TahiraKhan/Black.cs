﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checkers_TahiraKhan
{
    public class Black : BoardPieces
    {
        public Black(int x, int y, string image): base(x,y,image)
        {
        }

    }
}
