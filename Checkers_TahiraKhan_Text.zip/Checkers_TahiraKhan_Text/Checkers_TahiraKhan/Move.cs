﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checkers_TahiraKhan
{
     class Move
    {
        public bool turn = true;
        
        public BlackPiece blackpieces { get; set; }
        public WhitePiece whitepieces { get; set; }
        public BoardPieces underneath { get; set; }

       



    }

}
